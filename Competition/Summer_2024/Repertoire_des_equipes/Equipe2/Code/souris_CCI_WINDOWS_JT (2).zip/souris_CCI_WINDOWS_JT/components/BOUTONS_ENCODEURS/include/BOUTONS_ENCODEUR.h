#ifndef _BOUTONS_ENCODEURS_H
#define _BOUTONS_ENCODEURS_H

extern "C"
{
    #include <stdio.h>              // Standard I/O functions
    #include "esp_log.h"            // ESP-IDF logging functions
    //#include "driver/i2c_master.h" // (Commented-out) I2C master driver header
    #include "freertos/FreeRTOS.h"  // FreeRTOS base functions
    #include "freertos/task.h"      // FreeRTOS task management
    #include "driver/gpio.h"        // GPIO driver functions
}

// Define constants for sampling interval and GPIO pins
#define SAMPLING_INTERVAL           0.01 // Sampling interval of 0.01 seconds (100Hz)
#define LEFT_CLICK 9                // GPIO pin number for left click
#define RIGHT_CLICK 8               // GPIO pin number for right click
#define UP_SCROLL 5                 // GPIO pin number for up scroll
#define DOWN_SCROLL 4               // GPIO pin number for down scroll

extern QueueHandle_t gpio_evt_queue; // External declaration of GPIO event queue

// Class to handle GPIO button events
class MAGOUILLE {
public:
    // Constructor to initialize GPIO pins for buttons and scrolls
    MAGOUILLE(gpio_num_t L, gpio_num_t R, gpio_num_t U, gpio_num_t D);
    // Destructor
    ~MAGOUILLE();
    // Method to initialize GPIO settings and ISR
    void init();
    // Static ISR handler for GPIO interrupts
    static void IRAM_ATTR gpio_isr_handler(void* arg);
    // Static constant for logging tag
    static const char* TAG;

    int detect_scroll_direction(); // Method to detect scroll direction

private:
    gpio_num_t L_button;   // GPIO pin number for left button
    gpio_num_t R_button;   // GPIO pin number for right button
    gpio_num_t U_Scroll;   // GPIO pin number for up scroll
    gpio_num_t D_Scroll;   // GPIO pin number for down scroll
    int gpio_all_input_mask; // Mask for all GPIO inputs
    int previous_U_state = 0;  // Previous state of A
    int previous_D_state = 0;  // Previous state of B
protected:
};

// Function to handle GPIO events in a task
void handle_gpio_task(void* arg);

#endif
