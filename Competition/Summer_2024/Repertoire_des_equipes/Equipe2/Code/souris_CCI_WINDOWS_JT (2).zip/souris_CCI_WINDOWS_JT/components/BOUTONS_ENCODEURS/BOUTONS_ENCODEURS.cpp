extern "C"
{
    #include <stdio.h>              // Standard I/O functions
    #include "esp_log.h"            // ESP-IDF logging functions
    //#include "driver/i2c_master.h" // (Commented-out) I2C master driver header
    #include "freertos/FreeRTOS.h"  // FreeRTOS base functions
    #include "freertos/task.h"      // FreeRTOS task management
    #include "driver/gpio.h"        // GPIO driver functions
    #include "freertos/queue.h"     // FreeRTOS queue functions
    #include <stdlib.h>             // Standard library functions
}
#include "BOUTONS_ENCODEUR.h"       // Custom header for encoder buttons

#define ESP_INTR_FLAG_DEFAULT 0     // Default interrupt flag for GPIO

QueueHandle_t gpio_evt_queue = NULL; // Queue handle for GPIO events

const char* MAGOUILLE::TAG = "GPIO_ISR"; // Tag for logging

// Constructor for MAGOUILLE class, initializing GPIO pins
MAGOUILLE::MAGOUILLE(gpio_num_t L, gpio_num_t R, gpio_num_t U, gpio_num_t D)
{
    L_button = L;          // Left button GPIO pin
    R_button = R;          // Right button GPIO pin
    U_Scroll = U;          // Up scroll GPIO pin
    D_Scroll = D;          // Down scroll GPIO pin
    gpio_all_input_mask = ((1ULL<<L_button)|(1ULL<<R_button)|(1ULL<<U_Scroll)|(1ULL<<D_Scroll)); // Mask for all GPIO inputs
}

// Destructor for MAGOUILLE class
MAGOUILLE::~MAGOUILLE()
{

}

// Initialize GPIO settings and ISR service
void MAGOUILLE::init()
{
    gpio_config_t io_conf = {};                     // GPIO configuration structure
    io_conf.intr_type = GPIO_INTR_ANYEDGE;          // Trigger on both edges (rising and falling)
    io_conf.mode = GPIO_MODE_INPUT;                 // Set GPIO pins as input
    io_conf.pin_bit_mask = (gpio_all_input_mask);   // Apply mask for the specified GPIO pins
    io_conf.pull_down_en = GPIO_PULLDOWN_ENABLE;    // Enable pull-down resistors
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;       // Disable pull-up resistors
    gpio_config(&io_conf);                         // Configure GPIO pins

    gpio_evt_queue = xQueueCreate(10, sizeof(uint32_t)); // Create a queue to hold GPIO events

    if (gpio_evt_queue == NULL) {
        ESP_LOGE(TAG, "Failed to create GPIO event queue"); // Log error if queue creation fails
        return;
    }

    gpio_install_isr_service(ESP_INTR_FLAG_DEFAULT); // Install GPIO ISR service
    // Add ISR handlers for each GPIO pin
    gpio_isr_handler_add(L_button, gpio_isr_handler, (void*) (intptr_t)L_button);
    gpio_isr_handler_add(R_button, gpio_isr_handler, (void*) (intptr_t)R_button);
    gpio_isr_handler_add(U_Scroll, gpio_isr_handler, (void*) (intptr_t)U_Scroll);
    gpio_isr_handler_add(D_Scroll, gpio_isr_handler, (void*) (intptr_t)D_Scroll);
}

// ISR handler for GPIO interrupts
void IRAM_ATTR MAGOUILLE::gpio_isr_handler(void* arg)
{
    uint32_t gpio_num = (uint32_t)(intptr_t)arg; // Cast argument to GPIO pin number
    xQueueSendFromISR(gpio_evt_queue, &gpio_num, NULL); // Send GPIO pin number to the queue from ISR
}

// Method to detect scroll direction
int MAGOUILLE::detect_scroll_direction()
{
    int U_state = gpio_get_level(U_Scroll);
    int D_state = gpio_get_level(D_Scroll);
    ESP_LOGE(TAG, "Test Up: %d", U_state); 
    ESP_LOGE(TAG, "Test Down: %d", D_state); 
    ESP_LOGI(TAG, "Test previous Up: %d", previous_U_state); 
    ESP_LOGI(TAG, "Test previous Down: %d", previous_D_state);

    if ((previous_U_state == 0 && previous_D_state == 0) && (U_state == 1 && D_state == 0)) 
    {
        ESP_LOGI(TAG, "Scroll Up");
        return(1);
    } 
    else if ((previous_U_state == 0 && previous_D_state == 1) && (U_state == 1 && D_state == 1)) 
    {
        ESP_LOGI(TAG, "Scroll Up");
        return(1);
    }
    else if ((previous_U_state == 1 && previous_D_state == 1) && (U_state == 0 && D_state == 1)) 
    {
        ESP_LOGI(TAG, "Scroll Up");
        return(1);
    }
    else if ((previous_U_state == 1 && previous_D_state == 0) && (U_state == 0 && D_state == 0)) 
    {
        ESP_LOGI(TAG, "Scroll Up");
        return(1);
    }
    else if ((previous_U_state == 1 && previous_D_state == 0) && (U_state == 0 && D_state == 0)) 
    {
        ESP_LOGI(TAG, "Scroll Down");
        return 2;
    } 
    else if ((previous_U_state == 0 && previous_D_state == 0) && (U_state == 0 && D_state == 1)) 
    {
        ESP_LOGI(TAG, "Scroll Down");
        return 2;
    }
    else if ((previous_U_state == 0 && previous_D_state == 1) && (U_state == 1 && D_state == 1)) 
    {
        ESP_LOGI(TAG, "Scroll Down");
        return 2;
    }
    else if ((previous_U_state == 1 && previous_D_state == 1) && (U_state == 1 && D_state == 0)) 
    {
        ESP_LOGI(TAG, "Scroll Down");
        return 2;
    }
    else
    {
        return(0);
    }
    previous_U_state = U_state;
    previous_D_state = D_state;
}

// Task to handle GPIO events
void handle_gpio_task(void* arg)
{
    MAGOUILLE* instance = static_cast<MAGOUILLE*>(arg); // Cast argument to MAGOUILLE instance
    uint32_t io_num;                                  // Variable to hold GPIO pin number
    int state = 0;                                   // Variable to hold GPIO pin state

    for(;;) {
        if(xQueueReceive(gpio_evt_queue, &io_num, portMAX_DELAY)) { // Wait for GPIO event
            state = gpio_get_level(static_cast<gpio_num_t>(io_num)); // Get the state of the GPIO pin
            ESP_LOGI(instance->TAG, "GPIO %ld triggered state is %d", io_num, state); // Log GPIO event
            UBaseType_t stackHighWaterMark = uxTaskGetStackHighWaterMark(NULL); // Get stack high water mark
            ESP_LOGI("STACK", "Stack high water mark: %d", stackHighWaterMark); // Log stack high water mark
        }
    }
}
